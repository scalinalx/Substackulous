// Follow this setup guide to integrate the Deno language server with your editor:
// https://deno.land/manual/getting_started/setup_your_environment
// This enables autocomplete, go to definition, etc.

// Setup type definitions for built-in Supabase Runtime APIs
import "jsr:@supabase/functions-js/edge-runtime.d.ts"

import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'
import Stripe from 'https://esm.sh/stripe@12.0.0'

const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY')!, {
  apiVersion: '2024-06-20',
})

console.log("Hello from Functions!")

// Helper function to convert hex string to Uint8Array
function hexToUint8Array(hex: string): Uint8Array {
  return new Uint8Array(hex.match(/.{1,2}/g)!.map(byte => parseInt(byte, 16)));
}

// Helper function to verify Stripe signature
async function verifyStripeSignature(
  payload: string,
  sigHeader: string,
  secret: string
): Promise<boolean> {
  try {
    const pairs = sigHeader.split(',');
    const timestamp = pairs.find(pair => pair.startsWith('t='))?.split('=')[1];
    const signatures = pairs
      .filter(pair => pair.startsWith('v1='))
      .map(pair => pair.split('=')[1]);

    if (!timestamp || signatures.length === 0) {
      console.error('Invalid signature format');
      return false;
    }

    const encoder = new TextEncoder();
    const key = await crypto.subtle.importKey(
      'raw',
      encoder.encode(secret),
      { name: 'HMAC', hash: 'SHA-256' },
      false,
      ['sign']
    );

    const signedPayload = `${timestamp}.${payload}`;
    const expectedSignature = await crypto.subtle.sign(
      'HMAC',
      key,
      encoder.encode(signedPayload)
    );

    const expectedSignatureHex = Array.from(new Uint8Array(expectedSignature))
      .map(b => b.toString(16).padStart(2, '0'))
      .join('');

    return signatures.some(sig => sig === expectedSignatureHex);
  } catch (err) {
    console.error('Error verifying signature:', err);
    return false;
  }
}

serve(async (req) => {
  // Enable CORS
  if (req.method === 'OPTIONS') {
    return new Response('ok', {
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'POST',
        'Access-Control-Allow-Headers': 'Content-Type, stripe-signature',
      },
    })
  }

  try {
    console.log('Webhook received')
    const signature = req.headers.get('stripe-signature')
    if (!signature) {
      console.error('No signature found')
      return new Response('No signature', { status: 400 })
    }

    const body = await req.text()
    console.log('Verifying signature...')
    console.log('Signature header:', signature)
    
    const isValid = await verifyStripeSignature(
      body,
      signature,
      Deno.env.get('STRIPE_WEBHOOK_SECRET')!
    );

    if (!isValid) {
      console.error('Invalid signature')
      return new Response('Invalid signature', { status: 400 })
    }

    const event = JSON.parse(body);
    console.log('Signature verified, processing event:', event.type)

    // Initialize Supabase client
    const supabaseAdmin = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    )

    // Handle checkout.session.completed
    if (event.type === 'checkout.session.completed') {
      console.log('Processing checkout.session.completed');
      const session = event.data.object;
      const customerEmail = session.customer_details?.email;
      const isSubscription = session.mode === 'subscription';
      
      console.log('Customer email:', customerEmail);
      console.log('Is subscription:', isSubscription);

      if (!customerEmail) {
        console.error('No customer email found in session');
        throw new Error('No customer email found');
      }

      // 1. Get current user profile
      console.log('Fetching user profile');
      const { data: profile, error: profileError } = await supabaseAdmin
        .from('profiles')
        .select('*')
        .eq('email', customerEmail)
        .single();

      if (profileError) {
        console.error('Profile fetch error:', profileError);
        throw profileError;
      }

      if (!profile) {
        console.error('Profile not found for email:', customerEmail);
        throw new Error('Profile not found');
      }

      const creditsToAdd = Number(session.metadata?.credits || 0);
      const planType = session.metadata?.plan || 'one_time';
      console.log('Credits to add:', creditsToAdd);
      console.log('Plan type:', planType);

      // 2. Update profile
      console.log('Updating user profile');
      const { error: updateError } = await supabaseAdmin
        .from('profiles')
        .update({
          credits: (profile.credits || 0) + creditsToAdd,
          subscription_id: isSubscription ? session.subscription as string : null,
          subscription_plan: isSubscription ? planType : profile.subscription_plan,
          subscription_status: isSubscription ? 'active' : profile.subscription_status,
          plan_start_date: isSubscription ? new Date().toISOString() : profile.plan_start_date,
          credits_reset_date: isSubscription 
            ? new Date(Date.now() + (planType === 'LEGEND' ? 365 : 30) * 24 * 60 * 60 * 1000).toISOString()
            : null
        })
        .eq('email', customerEmail);

      if (updateError) {
        console.error('Profile update error:', updateError);
        throw updateError;
      }

      // 3. Log credit purchase
      if (creditsToAdd > 0) {
        console.log('Logging credit purchase');
        const { error: creditLogError } = await supabaseAdmin
          .from('credit_purchase_logs')
          .insert({
            user_email: customerEmail,
            credits_added: creditsToAdd,
            purchase_type: isSubscription ? planType : 'one_time',
            timestamp: new Date().toISOString(),
            expiration_date: isSubscription 
              ? new Date(Date.now() + (planType === 'LEGEND' ? 365 : 30) * 24 * 60 * 60 * 1000).toISOString()
              : new Date(Date.now() + 90 * 24 * 60 * 60 * 1000).toISOString()
          });

        if (creditLogError) {
          console.error('Credit purchase log error:', creditLogError);
          throw creditLogError;
        }
      }

      // 4. Log subscription change if applicable
      if (isSubscription) {
        console.log('Logging subscription change');
        const { error: subscriptionLogError } = await supabaseAdmin
          .from('subscription_logs')
          .insert({
            user_email: customerEmail,
            previous_plan: profile.subscription_plan || 'none',
            new_plan: planType,
            subscription_id: session.subscription as string,
            credits_remaining: profile.credits || 0,
            credits_added: creditsToAdd,
            event: 'subscription_started',
            timestamp: new Date().toISOString()
          });

        if (subscriptionLogError) {
          console.error('Subscription log error:', subscriptionLogError);
          throw subscriptionLogError;
        }
      }

      // 5. Log payment
      console.log('Logging payment');
      const { error: paymentLogError } = await supabaseAdmin
        .from('payment_logs')
        .insert({
          user_email: customerEmail,
          subscription_id: isSubscription ? session.subscription as string : null,
          event: isSubscription ? 'subscription_payment' : 'one_time_payment',
          timestamp: new Date().toISOString(),
          details: JSON.stringify(session),
          resolved: true,
          resolution_date: new Date().toISOString(),
          attempt_count: 1
        });

      if (paymentLogError) {
        console.error('Payment log error:', paymentLogError);
        throw paymentLogError;
      }

      console.log('Successfully processed checkout session');
      return new Response(JSON.stringify({ received: true }), {
        headers: { 'Content-Type': 'application/json' },
      });
    }

    // Handle subscription cancellation
    if (event.type === 'customer.subscription.deleted') {
      console.log('Processing subscription cancellation');
      const subscription = event.data.object;
      // Get customer email from subscription
      const customer = await stripe.customers.retrieve(subscription.customer as string);
      if (!customer || !('email' in customer)) {
        throw new Error('Retrieved customer is not valid');
      }
      const customerEmail = (customer as any).email;

      console.log('Subscription details:', {
        id: subscription.id,
        customerEmail,
        status: subscription.status,
        cancelAt: subscription.cancel_at
      });

      if (!customerEmail) {
        console.error('No customer email found in subscription');
        throw new Error('No customer email found');
      }

      // Get current user profile
      console.log('Fetching user profile for cancellation');
      const { data: profile, error: profileError } = await supabaseAdmin
        .from('profiles')
        .select('*')
        .eq('email', customerEmail)
        .single();

      if (profileError) {
        console.error('Profile fetch error during cancellation:', profileError);
        throw profileError;
      }

      // Update profile subscription status
      console.log('Updating profile subscription status');
      const { error: updateError } = await supabaseAdmin
        .from('profiles')
        .update({
          subscription_status: 'canceled',
          subscription_id: null,
          subscription_plan: 'Starter',
          plan_start_date: null,
          credits_reset_date: null
        })
        .eq('email', customerEmail);

      if (updateError) {
        console.error('Profile update error during cancellation:', updateError);
        throw updateError;
      }

      // Log subscription cancellation
      console.log('Logging subscription cancellation');
      const { error: subscriptionLogError } = await supabaseAdmin
        .from('subscription_logs')
        .insert({
          user_email: customerEmail,
          previous_plan: profile?.subscription_plan || 'unknown',
          new_plan: 'Starter',
          subscription_id: subscription.id,
          credits_remaining: profile?.credits || 0,
          event: 'subscription_canceled',
          timestamp: new Date().toISOString()
        });

      if (subscriptionLogError) {
        console.error('Subscription cancellation log error:', subscriptionLogError);
        throw subscriptionLogError;
      }

      console.log('Successfully processed subscription cancellation');
      return new Response(JSON.stringify({ received: true }), {
        headers: { 'Content-Type': 'application/json' },
      });
    }

    // Handle payment failure
    if (event.type === 'invoice.payment_failed') {
      console.log('Processing payment failure');
      const invoice = event.data.object;
      const customerEmail = invoice.customer_email;

      console.log('Invoice payment failure details:', {
        id: invoice.id,
        customerEmail,
        amount: invoice.amount_due,
        status: invoice.status
      });

      if (!customerEmail) {
        console.error('No customer email found in invoice');
        throw new Error('No customer email found');
      }

      // Log payment failure
      console.log('Logging payment failure');
      const { error: paymentLogError } = await supabaseAdmin
        .from('payment_logs')
        .insert({
          user_email: customerEmail,
          subscription_id: invoice.subscription as string,
          event: 'payment_failed',
          timestamp: new Date().toISOString(),
          details: JSON.stringify(invoice),
          resolved: false,
          attempt_count: (invoice.attempt_count || 1)
        });

      if (paymentLogError) {
        console.error('Payment failure log error:', paymentLogError);
        throw paymentLogError;
      }

      // Update profile subscription status
      console.log('Updating profile payment status');
      const { error: updateError } = await supabaseAdmin
        .from('profiles')
        .update({
          subscription_status: 'payment_failed'
        })
        .eq('email', customerEmail);

      if (updateError) {
        console.error('Profile update error during payment failure:', updateError);
        throw updateError;
      }

      console.log('Successfully processed payment failure');
      return new Response(JSON.stringify({ received: true }), {
        headers: { 'Content-Type': 'application/json' },
      });
    }

    console.log('Successfully processed webhook');
    return new Response(JSON.stringify({ received: true }), {
      headers: { 'Content-Type': 'application/json' },
    });
  } catch (err) {
    console.error('Webhook error:', err);
    return new Response(
      JSON.stringify({ error: err.message }),
      { status: 400, headers: { 'Content-Type': 'application/json' } }
    );
  }
})

/* To invoke locally:

  1. Run `supabase start` (see: https://supabase.com/docs/reference/cli/supabase-start)
  2. Make an HTTP request:

  curl -i --location --request POST 'http://127.0.0.1:54321/functions/v1/stripe-webhook' \
    --header 'Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZS1kZW1vIiwicm9sZSI6ImFub24iLCJleHAiOjE5ODM4MTI5OTZ9.CRXP1A7WOeoJeXxjNni43kdQwgnWNReilDMblYTn_I0' \
    --header 'Content-Type: application/json' \
    --header 'stripe-signature: your-test-signature' \
    --data '{"type":"checkout.session.completed","data":{"object":{"customer_details":{"email":"test@example.com"},"metadata":{"credits":"250","plan":"one_time"}}}}'

*/
